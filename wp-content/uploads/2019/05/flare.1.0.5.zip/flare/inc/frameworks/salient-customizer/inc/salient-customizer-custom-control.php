<?php
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/custom-control/salient-radio-image-control.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/custom-control/salient-category-control.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/custom-control/salient-post-dropdown-control.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/custom-control/salient-tags-dropdown-control.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/custom-control/salient-user-dropdown-control.php';
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/custom-control/salient-message-control.php';
