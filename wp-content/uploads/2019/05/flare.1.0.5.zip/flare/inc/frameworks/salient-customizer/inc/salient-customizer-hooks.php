<?php
require_once trailingslashit( SALIENT_CUSTOMIZER_PATH ) . 'inc/hooks/add-setting-controls.php';